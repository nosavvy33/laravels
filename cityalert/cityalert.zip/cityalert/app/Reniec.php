<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Reniec extends Model
{
    protected $table = 'reniec';
    protected $primaryKey = 'idreniec';
    public $timestamps = false;
}
