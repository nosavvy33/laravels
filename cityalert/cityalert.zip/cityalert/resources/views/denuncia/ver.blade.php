@foreach($datos as $dato)
{{$dato->celular}}
{{$dato->imei}}
{{$dato->foto}}
@endforeach