@foreach($usuarios as $usuario)
{{$usuario->nombres}}
@endforeach