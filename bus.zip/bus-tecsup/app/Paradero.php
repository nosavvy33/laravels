<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Paradero extends Model
{
    protected $table = 'paradero';
    protected $primaryKey = 'idparadero';
}
