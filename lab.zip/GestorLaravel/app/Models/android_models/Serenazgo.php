<?php

namespace App\Models\android_models;

use Illuminate\Database\Eloquent\Model;

class Serenazgo extends Model
{
    protected $table="serenazgo";
    
    protected $primaryKey = 'idserenazgo';

    public $timestamps = false;

}
