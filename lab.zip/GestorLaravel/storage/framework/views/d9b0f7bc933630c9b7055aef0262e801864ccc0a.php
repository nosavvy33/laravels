<a href="/auto/nuevo">Nuevo</a>
<table >
	<tr>
		<th>Placa</th>
	<th>Color</th>
	<th>Id</th>
	<th>Acciones</th>
	</tr>
	<?php $__currentLoopData = $autos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $auto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	<tr>
		<th><?php echo e($auto->placa); ?></th>
	<th><?php echo e($auto->color); ?></th>
	<th><?php echo e($auto->id); ?></th>
	<th>
		<a href="/auto/editar/<?php echo e($auto->id); ?>">Editar</a>
			<a href="/auto/eliminar/<?php echo e($auto->id); ?>">Eliminar</a>

	</th>
	</tr>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</table>





