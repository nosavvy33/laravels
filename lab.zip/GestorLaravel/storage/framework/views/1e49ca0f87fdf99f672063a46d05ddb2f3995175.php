<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>POST-EDIT</title>
</head>
<body>
<h1>EDITAR POST</h1>
<form method="POST" action="/post/update">
	<?php echo e(csrf_field()); ?>

	<input type="text" name="title" value="<?php echo e($post->title); ?>" style="display: inline;"><strong> Usuario : <?php echo e($post->users->name); ?></strong><br>	<textarea name="body" value="<?php echo e($post->body); ?>"><?php echo e($post->body); ?></textarea>
	<input type="hidden" name="post_id" value="<?php echo e($post->id); ?>">
	<input type="hidden" name="user_id" value="<?php echo e($post->user_id); ?>">
	<input type="submit" value="Guardar cambios">
</form>
</body>
</html>