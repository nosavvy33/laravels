<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>POST-CREATE</title>
</head>
<body>
<h1>CREAR POST</h1>
<form method="POST" action="/post/store">
	<?php echo e(csrf_field()); ?>

	<input type="text" name="title" style="display:inline;"><select name="user">
		<?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<option value="<?php echo e($user->id); ?>"><?php echo e($user->name); ?></option>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</select><br>	
	<textarea name="body"></textarea>
	<input type="submit" value="Crear post">
</form>
</body>
</html>