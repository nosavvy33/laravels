<!DOCTYPE html>
<html>
<head>
	<title>holi</title>
</head>
<body>
<form method="POST" action="/auto/update">
	<?php echo e(csrf_field()); ?>

	<input type="text" value="<?php echo e($placa); ?>" name="placa"><br>
	<input type="text"	value="<?php echo e($color); ?>" name="color"><br>
	<input type="hidden"	value="<?php echo e($id); ?>" name="id">
<input type="submit" name="" value="Enviar">
</form>
</body>
</html>