<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>USER-EDIT</title>
</head>
<body>
<h1>EDITAR USUARIO</h1>
<form method="POST" action="/user/update">
	<?php echo e(csrf_field()); ?>

	<input type="hidden" name="id" value="<?php echo e($id); ?>">
	<input type="text" name="name" value="<?php echo e($name); ?>">
	<input type="submit" value="Guardar cambios">
</form>
</body>
</html>