<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>USER-LIST</title>
</head>
<body>
<h1>Lista de usuarios</h1>
<table border=1>

	<a href="/user/create">Crear usuario</a>
	<br>
	<thead>
		<tr>
			<td>ID</td>
			<td>NOMBRE</td>
			<td>Editar</td>
			<td>Eliminar</td>
		</tr>
	</thead>
	<tbody>
		<?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<tr>
				<td><?php echo e($user->id); ?></td>
				<td><?php echo e($user->name); ?></td>
				<td><a href="/user/edit/<?php echo e($user->id); ?>">Editar</a></td>
				<td><a href="/user/destroy/<?php echo e($user->id); ?>">Eliminar</a></td>
			</tr>

		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</tbody>
</table>
</body>
</html>