<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>POST-LIST</title>
</head>
<body>
<h1>Lista de posts</h1>
<table border=1>

	<a href="/post/create">Crear post</a>
	<br>
	<thead>
		<tr>
			<td>ID</td>
			<td>TITLE</td>
			<td>BODY</td>
			<td>USUARIO</td>
			<td>Editar</td>
			<td>Eliminar</td>
		</tr>
	</thead>
	<tbody>
		<?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<tr>
				<td><?php echo e($post->id); ?></td>
				<td><?php echo e($post->title); ?></td>
				<td><?php echo e($post->body); ?></td>				
				<td><?php echo e($post->users->name); ?></td>
				<td><a href="/post/edit/<?php echo e($post->id); ?>">Editar</a></td>
				<td><a href="/post/destroy/<?php echo e($post->id); ?>">Eliminar</a></td>
			</tr>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</tbody>
</table>
</body>
</html>